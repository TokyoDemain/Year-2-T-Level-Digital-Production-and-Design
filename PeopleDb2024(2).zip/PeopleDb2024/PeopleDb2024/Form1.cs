﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PeopleDb2024
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAddRecord_Click(object sender, EventArgs e)
        {
            try { 
                string connectionString = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\M2202787\\OneDrive - Middlesbrough College\\Documents\\2023 - 2024 C# Programming\\PeopleDb2024\\PeopleDB2024.mdf; Integrated Security = True; Connect Timeout = 30";

                SqlConnection sqlConnection = new SqlConnection(connectionString);

                //Use stored procedure

                SqlCommand command = new SqlCommand("CreateNewPersonRecord", sqlConnection);

                command.CommandType = CommandType.StoredProcedure;

                //Input name and age from form

                string name = txtName.Text;

                int age = int.Parse(txtAge.Text);

                string Address = txtAddress.Text;

                string TelephoneNumber = txtTelephoneNumber.Text;

                //Call stored procedure passing name and age as parameters

                command.Parameters.AddWithValue("@Name", name);

                command.Parameters.AddWithValue("@Age", age);

                command.Parameters.AddWithValue("@Address", Address);

                command.Parameters.AddWithValue("@TelephoneNumber", TelephoneNumber);

                //Open connection to database, execute stored procedure and close the connection

                sqlConnection.Open();

                command.ExecuteNonQuery();

                sqlConnection.Close();

                MessageBox.Show("Saved");

                txtName.Text = "";
                txtAge.Text = "";
                txtAddress.Text = "";
                txtTelephoneNumber.Text = "";

            }
            catch { MessageBox.Show("Error"); }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            List<Person> peopleList = new List<Person>();
            string connectionString = "Data Source = (LocalDB)\\MSSQLLocalDB;AttachDbFilename = C:\\Users\\M2202787\\OneDrive - Middlesbrough College\\Documents\\2023 - 2024 C# Programming\\PeopleDb2024\\PeopleDB2024.mdf; Integrated Security = True; Connect Timeout = 30";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("GetPersonDetails", sqlConnection);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sqlConnection.Open();
            sd.Fill(dt);
            sqlConnection.Close();
            foreach(DataRow dr in dt.Rows)
            {
                peopleList.Add(
                    new Person()
                    {
                        Id = Convert.ToInt32(dr["Id"]),
                        Name = Convert.ToString(dr["Name"]),
                        Age = Convert.ToInt32(dr["Age"]),
                        Address = Convert.ToString(dr["Address"]),
                        TelephoneNumber = Convert.ToString(dr["Telephone Number"])
                    }
                );
            }
            foreach (Person person in peopleList)
            {
                txtPeople.AppendText(person.Name + "\t" + person.Age.ToString() + "\t" + person.Address + "\t" + person.TelephoneNumber + Environment.NewLine);
            }
        }
    }
}
