﻿namespace Methods_2_please_dont_dissapear
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.btnHypotCalc = new System.Windows.Forms.Button();
            this.txtHypotOut = new System.Windows.Forms.TextBox();
            this.txtTaxiCalcIn = new System.Windows.Forms.TextBox();
            this.btnTaxiCalc = new System.Windows.Forms.Button();
            this.txtTaxiCalcOut = new System.Windows.Forms.TextBox();
            this.txtOunces = new System.Windows.Forms.TextBox();
            this.btnWeightCalculate = new System.Windows.Forms.Button();
            this.txtPounds = new System.Windows.Forms.TextBox();
            this.txtGrams = new System.Windows.Forms.TextBox();
            this.txtKilos = new System.Windows.Forms.TextBox();
            this.txtRadiusIn = new System.Windows.Forms.TextBox();
            this.btnCircleCalc = new System.Windows.Forms.Button();
            this.txtDiameterOut = new System.Windows.Forms.TextBox();
            this.txtCircumferanceOut = new System.Windows.Forms.TextBox();
            this.txtAreaOutput = new System.Windows.Forms.TextBox();
            this.lstDeptOut = new System.Windows.Forms.ListBox();
            this.txtAnnualIncome = new System.Windows.Forms.TextBox();
            this.txtTotalDepts = new System.Windows.Forms.TextBox();
            this.txtFamilyPopNum = new System.Windows.Forms.TextBox();
            this.txtFamilyIDNum = new System.Windows.Forms.TextBox();
            this.btnDeptCalc = new System.Windows.Forms.Button();
            this.lblFamiltIDNum = new System.Windows.Forms.Label();
            this.lblNumberOfFamilyMembers = new System.Windows.Forms.Label();
            this.lblAnnualIncome = new System.Windows.Forms.Label();
            this.lblTotalDepts = new System.Windows.Forms.Label();
            this.txtUnitCostProduct = new System.Windows.Forms.TextBox();
            this.txtSaleVolume = new System.Windows.Forms.TextBox();
            this.cbWasPaidOnTime = new System.Windows.Forms.CheckBox();
            this.cbVATRated = new System.Windows.Forms.CheckBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.btnInvoiceCalc = new System.Windows.Forms.Button();
            this.lstInvoiceOut = new System.Windows.Forms.ListBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblUnitCost = new System.Windows.Forms.Label();
            this.lblSaleVolume = new System.Windows.Forms.Label();
            this.lblThankYouMessage = new System.Windows.Forms.Label();
            this.lblHypot = new System.Windows.Forms.Label();
            this.lblTaxiCalc = new System.Windows.Forms.Label();
            this.lblWeightCalc = new System.Windows.Forms.Label();
            this.lblCircleCalc = new System.Windows.Forms.Label();
            this.lblFamilyDeptCalc = new System.Windows.Forms.Label();
            this.lblInvoiceCalculator = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(12, 25);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(111, 20);
            this.txtA.TabIndex = 0;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(12, 51);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(111, 20);
            this.txtB.TabIndex = 1;
            // 
            // btnHypotCalc
            // 
            this.btnHypotCalc.Location = new System.Drawing.Point(12, 77);
            this.btnHypotCalc.Name = "btnHypotCalc";
            this.btnHypotCalc.Size = new System.Drawing.Size(111, 23);
            this.btnHypotCalc.TabIndex = 2;
            this.btnHypotCalc.Text = "Hypot Calc";
            this.btnHypotCalc.UseVisualStyleBackColor = true;
            this.btnHypotCalc.Click += new System.EventHandler(this.btnHypotCalc_Click);
            // 
            // txtHypotOut
            // 
            this.txtHypotOut.Location = new System.Drawing.Point(12, 106);
            this.txtHypotOut.Name = "txtHypotOut";
            this.txtHypotOut.Size = new System.Drawing.Size(111, 20);
            this.txtHypotOut.TabIndex = 3;
            // 
            // txtTaxiCalcIn
            // 
            this.txtTaxiCalcIn.Location = new System.Drawing.Point(129, 25);
            this.txtTaxiCalcIn.Name = "txtTaxiCalcIn";
            this.txtTaxiCalcIn.Size = new System.Drawing.Size(98, 20);
            this.txtTaxiCalcIn.TabIndex = 4;
            // 
            // btnTaxiCalc
            // 
            this.btnTaxiCalc.Location = new System.Drawing.Point(129, 51);
            this.btnTaxiCalc.Name = "btnTaxiCalc";
            this.btnTaxiCalc.Size = new System.Drawing.Size(98, 23);
            this.btnTaxiCalc.TabIndex = 5;
            this.btnTaxiCalc.Text = "Taxi Calc";
            this.btnTaxiCalc.UseVisualStyleBackColor = true;
            this.btnTaxiCalc.Click += new System.EventHandler(this.btnTaxiCalc_Click);
            // 
            // txtTaxiCalcOut
            // 
            this.txtTaxiCalcOut.Location = new System.Drawing.Point(129, 79);
            this.txtTaxiCalcOut.Name = "txtTaxiCalcOut";
            this.txtTaxiCalcOut.Size = new System.Drawing.Size(98, 20);
            this.txtTaxiCalcOut.TabIndex = 6;
            // 
            // txtOunces
            // 
            this.txtOunces.Location = new System.Drawing.Point(236, 25);
            this.txtOunces.Name = "txtOunces";
            this.txtOunces.Size = new System.Drawing.Size(88, 20);
            this.txtOunces.TabIndex = 7;
            // 
            // btnWeightCalculate
            // 
            this.btnWeightCalculate.Location = new System.Drawing.Point(236, 51);
            this.btnWeightCalculate.Name = "btnWeightCalculate";
            this.btnWeightCalculate.Size = new System.Drawing.Size(88, 23);
            this.btnWeightCalculate.TabIndex = 8;
            this.btnWeightCalculate.Text = "Weight Calc";
            this.btnWeightCalculate.UseVisualStyleBackColor = true;
            this.btnWeightCalculate.Click += new System.EventHandler(this.btnWeightCalculate_Click);
            // 
            // txtPounds
            // 
            this.txtPounds.Location = new System.Drawing.Point(236, 78);
            this.txtPounds.Name = "txtPounds";
            this.txtPounds.Size = new System.Drawing.Size(88, 20);
            this.txtPounds.TabIndex = 9;
            // 
            // txtGrams
            // 
            this.txtGrams.Location = new System.Drawing.Point(236, 104);
            this.txtGrams.Name = "txtGrams";
            this.txtGrams.Size = new System.Drawing.Size(88, 20);
            this.txtGrams.TabIndex = 10;
            // 
            // txtKilos
            // 
            this.txtKilos.Location = new System.Drawing.Point(236, 130);
            this.txtKilos.Name = "txtKilos";
            this.txtKilos.Size = new System.Drawing.Size(88, 20);
            this.txtKilos.TabIndex = 11;
            // 
            // txtRadiusIn
            // 
            this.txtRadiusIn.Location = new System.Drawing.Point(333, 25);
            this.txtRadiusIn.Name = "txtRadiusIn";
            this.txtRadiusIn.Size = new System.Drawing.Size(80, 20);
            this.txtRadiusIn.TabIndex = 12;
            // 
            // btnCircleCalc
            // 
            this.btnCircleCalc.Location = new System.Drawing.Point(333, 51);
            this.btnCircleCalc.Name = "btnCircleCalc";
            this.btnCircleCalc.Size = new System.Drawing.Size(80, 23);
            this.btnCircleCalc.TabIndex = 13;
            this.btnCircleCalc.Text = "Circle Calc";
            this.btnCircleCalc.UseVisualStyleBackColor = true;
            this.btnCircleCalc.Click += new System.EventHandler(this.btnCircleCalc_Click);
            // 
            // txtDiameterOut
            // 
            this.txtDiameterOut.Location = new System.Drawing.Point(334, 78);
            this.txtDiameterOut.Name = "txtDiameterOut";
            this.txtDiameterOut.Size = new System.Drawing.Size(79, 20);
            this.txtDiameterOut.TabIndex = 14;
            // 
            // txtCircumferanceOut
            // 
            this.txtCircumferanceOut.Location = new System.Drawing.Point(334, 104);
            this.txtCircumferanceOut.Name = "txtCircumferanceOut";
            this.txtCircumferanceOut.Size = new System.Drawing.Size(79, 20);
            this.txtCircumferanceOut.TabIndex = 15;
            this.txtCircumferanceOut.TextChanged += new System.EventHandler(this.txtCircumferanceOut_TextChanged);
            // 
            // txtAreaOutput
            // 
            this.txtAreaOutput.Location = new System.Drawing.Point(334, 130);
            this.txtAreaOutput.Name = "txtAreaOutput";
            this.txtAreaOutput.Size = new System.Drawing.Size(79, 20);
            this.txtAreaOutput.TabIndex = 16;
            // 
            // lstDeptOut
            // 
            this.lstDeptOut.FormattingEnabled = true;
            this.lstDeptOut.Location = new System.Drawing.Point(423, 159);
            this.lstDeptOut.Name = "lstDeptOut";
            this.lstDeptOut.Size = new System.Drawing.Size(276, 95);
            this.lstDeptOut.TabIndex = 17;
            // 
            // txtAnnualIncome
            // 
            this.txtAnnualIncome.Location = new System.Drawing.Point(422, 78);
            this.txtAnnualIncome.Name = "txtAnnualIncome";
            this.txtAnnualIncome.Size = new System.Drawing.Size(135, 20);
            this.txtAnnualIncome.TabIndex = 18;
            // 
            // txtTotalDepts
            // 
            this.txtTotalDepts.Location = new System.Drawing.Point(422, 103);
            this.txtTotalDepts.Name = "txtTotalDepts";
            this.txtTotalDepts.Size = new System.Drawing.Size(135, 20);
            this.txtTotalDepts.TabIndex = 19;
            // 
            // txtFamilyPopNum
            // 
            this.txtFamilyPopNum.Location = new System.Drawing.Point(422, 53);
            this.txtFamilyPopNum.Name = "txtFamilyPopNum";
            this.txtFamilyPopNum.Size = new System.Drawing.Size(135, 20);
            this.txtFamilyPopNum.TabIndex = 20;
            // 
            // txtFamilyIDNum
            // 
            this.txtFamilyIDNum.Location = new System.Drawing.Point(422, 25);
            this.txtFamilyIDNum.Name = "txtFamilyIDNum";
            this.txtFamilyIDNum.Size = new System.Drawing.Size(135, 20);
            this.txtFamilyIDNum.TabIndex = 21;
            // 
            // btnDeptCalc
            // 
            this.btnDeptCalc.Location = new System.Drawing.Point(422, 130);
            this.btnDeptCalc.Name = "btnDeptCalc";
            this.btnDeptCalc.Size = new System.Drawing.Size(277, 23);
            this.btnDeptCalc.TabIndex = 22;
            this.btnDeptCalc.Text = "Calcualte Dept";
            this.btnDeptCalc.UseVisualStyleBackColor = true;
            this.btnDeptCalc.Click += new System.EventHandler(this.btnDeptCalc_Click);
            // 
            // lblFamiltIDNum
            // 
            this.lblFamiltIDNum.AutoSize = true;
            this.lblFamiltIDNum.Location = new System.Drawing.Point(563, 28);
            this.lblFamiltIDNum.Name = "lblFamiltIDNum";
            this.lblFamiltIDNum.Size = new System.Drawing.Size(90, 13);
            this.lblFamiltIDNum.TabIndex = 23;
            this.lblFamiltIDNum.Text = "Family ID Number";
            // 
            // lblNumberOfFamilyMembers
            // 
            this.lblNumberOfFamilyMembers.AutoSize = true;
            this.lblNumberOfFamilyMembers.Location = new System.Drawing.Point(563, 56);
            this.lblNumberOfFamilyMembers.Name = "lblNumberOfFamilyMembers";
            this.lblNumberOfFamilyMembers.Size = new System.Drawing.Size(136, 13);
            this.lblNumberOfFamilyMembers.TabIndex = 24;
            this.lblNumberOfFamilyMembers.Text = "Number Of Family Members";
            // 
            // lblAnnualIncome
            // 
            this.lblAnnualIncome.AutoSize = true;
            this.lblAnnualIncome.Location = new System.Drawing.Point(563, 81);
            this.lblAnnualIncome.Name = "lblAnnualIncome";
            this.lblAnnualIncome.Size = new System.Drawing.Size(78, 13);
            this.lblAnnualIncome.TabIndex = 25;
            this.lblAnnualIncome.Text = "Annual Income";
            this.lblAnnualIncome.Click += new System.EventHandler(this.lblAnnualIncome_Click);
            // 
            // lblTotalDepts
            // 
            this.lblTotalDepts.AutoSize = true;
            this.lblTotalDepts.Location = new System.Drawing.Point(563, 106);
            this.lblTotalDepts.Name = "lblTotalDepts";
            this.lblTotalDepts.Size = new System.Drawing.Size(62, 13);
            this.lblTotalDepts.TabIndex = 26;
            this.lblTotalDepts.Text = "Total Depts";
            // 
            // txtUnitCostProduct
            // 
            this.txtUnitCostProduct.Location = new System.Drawing.Point(706, 56);
            this.txtUnitCostProduct.Name = "txtUnitCostProduct";
            this.txtUnitCostProduct.Size = new System.Drawing.Size(169, 20);
            this.txtUnitCostProduct.TabIndex = 27;
            // 
            // txtSaleVolume
            // 
            this.txtSaleVolume.Location = new System.Drawing.Point(706, 85);
            this.txtSaleVolume.Name = "txtSaleVolume";
            this.txtSaleVolume.Size = new System.Drawing.Size(169, 20);
            this.txtSaleVolume.TabIndex = 28;
            // 
            // cbWasPaidOnTime
            // 
            this.cbWasPaidOnTime.AutoSize = true;
            this.cbWasPaidOnTime.Location = new System.Drawing.Point(706, 112);
            this.cbWasPaidOnTime.Name = "cbWasPaidOnTime";
            this.cbWasPaidOnTime.Size = new System.Drawing.Size(169, 17);
            this.cbWasPaidOnTime.TabIndex = 29;
            this.cbWasPaidOnTime.Text = "Was the Invoice Paid on Time";
            this.cbWasPaidOnTime.UseVisualStyleBackColor = true;
            // 
            // cbVATRated
            // 
            this.cbVATRated.AutoSize = true;
            this.cbVATRated.Location = new System.Drawing.Point(706, 134);
            this.cbVATRated.Name = "cbVATRated";
            this.cbVATRated.Size = new System.Drawing.Size(148, 17);
            this.cbVATRated.TabIndex = 30;
            this.cbVATRated.Text = "Is the Product VAT Rated";
            this.cbVATRated.UseVisualStyleBackColor = true;
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(706, 28);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(169, 20);
            this.txtProductName.TabIndex = 31;
            // 
            // btnInvoiceCalc
            // 
            this.btnInvoiceCalc.Location = new System.Drawing.Point(706, 157);
            this.btnInvoiceCalc.Name = "btnInvoiceCalc";
            this.btnInvoiceCalc.Size = new System.Drawing.Size(169, 23);
            this.btnInvoiceCalc.TabIndex = 32;
            this.btnInvoiceCalc.Text = "Calculate Invoice";
            this.btnInvoiceCalc.UseVisualStyleBackColor = true;
            this.btnInvoiceCalc.Click += new System.EventHandler(this.btnInvoiceCalc_Click);
            // 
            // lstInvoiceOut
            // 
            this.lstInvoiceOut.FormattingEnabled = true;
            this.lstInvoiceOut.Location = new System.Drawing.Point(706, 186);
            this.lstInvoiceOut.Name = "lstInvoiceOut";
            this.lstInvoiceOut.Size = new System.Drawing.Size(169, 95);
            this.lstInvoiceOut.TabIndex = 33;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(881, 31);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(75, 13);
            this.lblProductName.TabIndex = 34;
            this.lblProductName.Text = "Product Name";
            // 
            // lblUnitCost
            // 
            this.lblUnitCost.AutoSize = true;
            this.lblUnitCost.Location = new System.Drawing.Point(881, 59);
            this.lblUnitCost.Name = "lblUnitCost";
            this.lblUnitCost.Size = new System.Drawing.Size(109, 13);
            this.lblUnitCost.TabIndex = 35;
            this.lblUnitCost.Text = "Unit Cost Per Product";
            // 
            // lblSaleVolume
            // 
            this.lblSaleVolume.AutoSize = true;
            this.lblSaleVolume.Location = new System.Drawing.Point(881, 88);
            this.lblSaleVolume.Name = "lblSaleVolume";
            this.lblSaleVolume.Size = new System.Drawing.Size(66, 13);
            this.lblSaleVolume.TabIndex = 36;
            this.lblSaleVolume.Text = "Sale Volume";
            // 
            // lblThankYouMessage
            // 
            this.lblThankYouMessage.AutoSize = true;
            this.lblThankYouMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThankYouMessage.ForeColor = System.Drawing.Color.Lime;
            this.lblThankYouMessage.Location = new System.Drawing.Point(700, 282);
            this.lblThankYouMessage.Name = "lblThankYouMessage";
            this.lblThankYouMessage.Size = new System.Drawing.Size(0, 55);
            this.lblThankYouMessage.TabIndex = 37;
            // 
            // lblHypot
            // 
            this.lblHypot.AutoSize = true;
            this.lblHypot.Location = new System.Drawing.Point(9, 9);
            this.lblHypot.Name = "lblHypot";
            this.lblHypot.Size = new System.Drawing.Size(114, 13);
            this.lblHypot.TabIndex = 38;
            this.lblHypot.Text = "Hypotenuse Calculator";
            // 
            // lblTaxiCalc
            // 
            this.lblTaxiCalc.AutoSize = true;
            this.lblTaxiCalc.Location = new System.Drawing.Point(126, 9);
            this.lblTaxiCalc.Name = "lblTaxiCalc";
            this.lblTaxiCalc.Size = new System.Drawing.Size(101, 13);
            this.lblTaxiCalc.TabIndex = 39;
            this.lblTaxiCalc.Text = "Taxi Cost Calculator";
            // 
            // lblWeightCalc
            // 
            this.lblWeightCalc.AutoSize = true;
            this.lblWeightCalc.Location = new System.Drawing.Point(233, 9);
            this.lblWeightCalc.Name = "lblWeightCalc";
            this.lblWeightCalc.Size = new System.Drawing.Size(91, 13);
            this.lblWeightCalc.TabIndex = 40;
            this.lblWeightCalc.Text = "Weight Calculator";
            this.lblWeightCalc.Click += new System.EventHandler(this.lblWeightCalc_Click);
            // 
            // lblCircleCalc
            // 
            this.lblCircleCalc.AutoSize = true;
            this.lblCircleCalc.Location = new System.Drawing.Point(330, 9);
            this.lblCircleCalc.Name = "lblCircleCalc";
            this.lblCircleCalc.Size = new System.Drawing.Size(83, 13);
            this.lblCircleCalc.TabIndex = 41;
            this.lblCircleCalc.Text = "Circle Calculator";
            // 
            // lblFamilyDeptCalc
            // 
            this.lblFamilyDeptCalc.AutoSize = true;
            this.lblFamilyDeptCalc.Location = new System.Drawing.Point(419, 9);
            this.lblFamilyDeptCalc.Name = "lblFamilyDeptCalc";
            this.lblFamilyDeptCalc.Size = new System.Drawing.Size(112, 13);
            this.lblFamilyDeptCalc.TabIndex = 42;
            this.lblFamilyDeptCalc.Text = "Family Dept Calculator";
            // 
            // lblInvoiceCalculator
            // 
            this.lblInvoiceCalculator.AutoSize = true;
            this.lblInvoiceCalculator.Location = new System.Drawing.Point(703, 9);
            this.lblInvoiceCalculator.Name = "lblInvoiceCalculator";
            this.lblInvoiceCalculator.Size = new System.Drawing.Size(92, 13);
            this.lblInvoiceCalculator.TabIndex = 43;
            this.lblInvoiceCalculator.Text = "Invoice Calculator";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 295);
            this.Controls.Add(this.lblInvoiceCalculator);
            this.Controls.Add(this.lblFamilyDeptCalc);
            this.Controls.Add(this.lblCircleCalc);
            this.Controls.Add(this.lblWeightCalc);
            this.Controls.Add(this.lblTaxiCalc);
            this.Controls.Add(this.lblHypot);
            this.Controls.Add(this.lblThankYouMessage);
            this.Controls.Add(this.lblSaleVolume);
            this.Controls.Add(this.lblUnitCost);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.lstInvoiceOut);
            this.Controls.Add(this.btnInvoiceCalc);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.cbVATRated);
            this.Controls.Add(this.cbWasPaidOnTime);
            this.Controls.Add(this.txtSaleVolume);
            this.Controls.Add(this.txtUnitCostProduct);
            this.Controls.Add(this.lblTotalDepts);
            this.Controls.Add(this.lblAnnualIncome);
            this.Controls.Add(this.lblNumberOfFamilyMembers);
            this.Controls.Add(this.lblFamiltIDNum);
            this.Controls.Add(this.btnDeptCalc);
            this.Controls.Add(this.txtFamilyIDNum);
            this.Controls.Add(this.txtFamilyPopNum);
            this.Controls.Add(this.txtTotalDepts);
            this.Controls.Add(this.txtAnnualIncome);
            this.Controls.Add(this.lstDeptOut);
            this.Controls.Add(this.txtAreaOutput);
            this.Controls.Add(this.txtCircumferanceOut);
            this.Controls.Add(this.txtDiameterOut);
            this.Controls.Add(this.btnCircleCalc);
            this.Controls.Add(this.txtRadiusIn);
            this.Controls.Add(this.txtKilos);
            this.Controls.Add(this.txtGrams);
            this.Controls.Add(this.txtPounds);
            this.Controls.Add(this.btnWeightCalculate);
            this.Controls.Add(this.txtOunces);
            this.Controls.Add(this.txtTaxiCalcOut);
            this.Controls.Add(this.btnTaxiCalc);
            this.Controls.Add(this.txtTaxiCalcIn);
            this.Controls.Add(this.txtHypotOut);
            this.Controls.Add(this.btnHypotCalc);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Name = "Form1";
            this.Text = "bigProgram";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Button btnHypotCalc;
        private System.Windows.Forms.TextBox txtHypotOut;
        private System.Windows.Forms.TextBox txtTaxiCalcIn;
        private System.Windows.Forms.Button btnTaxiCalc;
        private System.Windows.Forms.TextBox txtTaxiCalcOut;
        private System.Windows.Forms.TextBox txtOunces;
        private System.Windows.Forms.Button btnWeightCalculate;
        private System.Windows.Forms.TextBox txtPounds;
        private System.Windows.Forms.TextBox txtGrams;
        private System.Windows.Forms.TextBox txtKilos;
        private System.Windows.Forms.TextBox txtRadiusIn;
        private System.Windows.Forms.Button btnCircleCalc;
        private System.Windows.Forms.TextBox txtDiameterOut;
        private System.Windows.Forms.TextBox txtCircumferanceOut;
        private System.Windows.Forms.TextBox txtAreaOutput;
        private System.Windows.Forms.ListBox lstDeptOut;
        private System.Windows.Forms.TextBox txtAnnualIncome;
        private System.Windows.Forms.TextBox txtTotalDepts;
        private System.Windows.Forms.TextBox txtFamilyPopNum;
        private System.Windows.Forms.TextBox txtFamilyIDNum;
        private System.Windows.Forms.Button btnDeptCalc;
        private System.Windows.Forms.Label lblFamiltIDNum;
        private System.Windows.Forms.Label lblNumberOfFamilyMembers;
        private System.Windows.Forms.Label lblAnnualIncome;
        private System.Windows.Forms.Label lblTotalDepts;
        private System.Windows.Forms.TextBox txtUnitCostProduct;
        private System.Windows.Forms.TextBox txtSaleVolume;
        private System.Windows.Forms.CheckBox cbWasPaidOnTime;
        private System.Windows.Forms.CheckBox cbVATRated;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Button btnInvoiceCalc;
        private System.Windows.Forms.ListBox lstInvoiceOut;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblUnitCost;
        private System.Windows.Forms.Label lblSaleVolume;
        private System.Windows.Forms.Label lblThankYouMessage;
        private System.Windows.Forms.Label lblHypot;
        private System.Windows.Forms.Label lblTaxiCalc;
        private System.Windows.Forms.Label lblWeightCalc;
        private System.Windows.Forms.Label lblCircleCalc;
        private System.Windows.Forms.Label lblFamilyDeptCalc;
        private System.Windows.Forms.Label lblInvoiceCalculator;
    }
}

